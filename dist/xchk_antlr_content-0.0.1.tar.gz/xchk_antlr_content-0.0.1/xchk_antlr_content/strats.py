# custom checks and strategies go here
# note that it is highly recommended to put reusable checks and strategies in a separate app
