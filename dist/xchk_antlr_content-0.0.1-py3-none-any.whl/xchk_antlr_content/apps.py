from django.apps import AppConfig


class ANTLRcontentConfig(AppConfig):
    name = 'xchk_antlr_content'
